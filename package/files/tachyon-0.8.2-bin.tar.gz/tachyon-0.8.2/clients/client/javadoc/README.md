Javadoc placeholder to comply with Sonatype requirements.
