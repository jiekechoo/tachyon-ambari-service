#!/usr/bin/env bash

python <<EOF
import re

PATTERN = r'''<exclusion>
\s*<groupId>org\.tachyonproject</groupId>
\s*<artifactId>tachyon-underfs-s3</artifactId>
\s*</exclusion>'''
POM = '/spark/core/pom.xml'

new_pom = re.compile(PATTERN).sub('', open(POM).read())
open(POM, 'w').write(new_pom)
EOF
