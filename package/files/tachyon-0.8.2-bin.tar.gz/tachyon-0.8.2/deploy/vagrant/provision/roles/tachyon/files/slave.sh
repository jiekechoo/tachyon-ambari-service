#!/usr/bin/env bash

cp /vagrant/files/workers /tachyon/conf/workers
cp /vagrant/files/workers /tachyon/conf/slaves
